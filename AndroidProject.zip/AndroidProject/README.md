# DeadlineManager
Deadline Manager Android Studio Project

Prototype of an aplication that helps user to manage different types of tasks and meet all the deadlines
